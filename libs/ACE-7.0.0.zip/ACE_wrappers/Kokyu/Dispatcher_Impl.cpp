#include "Dispatcher_Impl.h"

#if ! defined (__ACE_INLINE__)
#include "Dispatcher_Impl.inl"
#endif /* __ACE_INLINE__ */

namespace Kokyu
{

//virtual - so don't inline
Dispatcher_Impl::~Dispatcher_Impl()
{
}

}
