#include "ACEXML/common/Attributes_Def_Builder.h"

ACEXML_Attribute_Def_Builder::~ACEXML_Attribute_Def_Builder ()
{

}

ACEXML_Attributes_Def_Builder::~ACEXML_Attributes_Def_Builder ()
{

}

