#include "ace/Containers.h"

#if !defined (__ACE_INLINE__)
#include "ace/Containers.inl"
#endif /* __ACE_INLINE__ */

ACE_ALLOC_HOOK_DEFINE (ACE_DLList_Node)
